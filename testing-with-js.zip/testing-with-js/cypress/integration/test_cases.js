const TEST_URL = 'https://jsonplaceholder.typicode.com/posts'

describe('Verify Posts API', function(){

    describe('Happy Path', function(){

        describe('Verify GET', function(){

            describe('Get All posts', function(){

                it('Verify API Contract', function(){
                    cy.request({
                        method: 'GET',
                        url: TEST_URL,
                    }).then(function(response){
                        expect(response.status).to.eq(200)
                        assert.isArray(response.body)
                        expect(response.body[0]).have.property('userId')
                        expect(response.body[0]).have.property('id')
                        expect(response.body[0]).have.property('title')
                        expect(response.body[0]).have.property('body')
                    });
                });
            
                it('Verify Responds with 100 Posts', function(){
                    cy.request({
                        method: 'GET',
                        url: TEST_URL,
                    }).then(function(response){
                        expect(response.status).to.eq(200)
                        expect(response.body.length).to.equal(100)
                    });
                });
            
            });

            describe('Get Specific post', function(){
            
                describe('By id', function(){
            
                    it('Verify API contract', function(){

                        cy.request({
                            method: 'GET',
                            url: TEST_URL,
                            qs: {
                                id: 1,
                            },
                        }).then(function(response){
                            expect(response.status).to.eq(200)
                            assert.isArray(response.body)
                            expect(response.body[0]).have.property('userId')
                            expect(response.body[0]).have.property('id')
                            expect(response.body[0]).have.property('title')
                            expect(response.body[0]).have.property('body')
                            expect(response.body.length).to.equal(1)
                            expect(response.body[0]["id"]).to.equal(1)
                        });

                    });

                    it('Verify correct post was retrieved', function(){

                        cy.request({
                            method: 'GET',
                            url: TEST_URL,
                            qs: {
                                id: 1,
                            },
                        }).then(function(response){
                            expect(response.status).to.eq(200)
                            expect(response.body[0]["id"]).to.equal(1)
                            expect(response.body[0]["userId"]).to.equal(1)
                            expect(response.body[0]["title"]).to.equal('sunt aut facere repellat provident occaecati excepturi optio reprehenderit')
                            expect(response.body[0]["body"]).to.equal('quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto')
                        });

                    });

                });

                describe('By userId', function(){
            
                    it('Verify API contract', function(){
                        let userId = 6

                        cy.request({
                            method: 'GET',
                            url: TEST_URL,
                            qs: {
                                userId: userId,
                            },
                        }).then(function(response){
                            expect(response.status).to.eq(200)
                            assert.isArray(response.body)
                            expect(response.body[0]).have.property('userId')
                            expect(response.body[0]).have.property('id')
                            expect(response.body[0]).have.property('title')
                            expect(response.body[0]).have.property('body')
                            expect(response.body.length).to.equal(10)
                            expect(response.body[0]["userId"]).to.equal(userId)
                        });

                    });

                    it('Verify correct post was retrieved', function(){
                        let userId = 6

                        cy.request({
                            method: 'GET',
                            url: TEST_URL,
                            qs: {
                                userId: userId,
                            },
                        }).then(function(response){
                            expect(response.status).to.eq(200)
                            expect(response.body[3]["id"]).to.equal(54)
                            expect(response.body[3]["userId"]).to.equal(userId)
                            expect(response.body[3]["title"]).to.equal('sit asperiores ipsam eveniet odio non quia')
                            expect(response.body[3]["body"]).to.equal('totam corporis dignissimos\nvitae dolorem ut occaecati accusamus\nex velit deserunt\net exercitationem vero incidunt corrupti mollitia')
                        });

                    });

                });

            });

        });

        describe('Verify POST', function(){
            
            it('Create new post', function(){

                let requestBody = {
                    userId: 11,
                    title: 'Come at me',
                    body: 'Come at me bro'
                }
            
                cy.request({
                    method: 'POST',
                    url: TEST_URL,
                    body: requestBody,
                }).then(function(response){
                    expect(response.status).to.eq(201)
                    expect(response.body["id"]).to.equal(101)
                    expect(response.body["userId"]).to.equal(requestBody["userId"])
                    expect(response.body["title"]).to.equal(requestBody["title"])
                    expect(response.body["body"]).to.equal(requestBody["body"])
                });

            });

        });

        describe('Verify PUT', function(){
            
            it('Update a post', function(){

                cy.request({
                    method: 'GET',
                    url: TEST_URL + '/1',
                }).then(response => {
                    var requestBody = response.body
                    requestBody["title"] = 'Updated title text'
                    requestBody["body"] = 'Updated body text'
                    cy.request({
                        method: 'PUT',
                        url: TEST_URL + '/' + requestBody["id"],
                        body: requestBody,
                    }).then(function(response){
                        expect(response.status).to.eq(200)
                        expect(response.body["id"]).to.equal(requestBody["id"])
                        expect(response.body["userId"]).to.equal(requestBody["userId"])
                        expect(response.body["title"]).to.equal(requestBody["title"])
                        expect(response.body["body"]).to.equal(requestBody["body"])
                    });

                });

            });

        });

        describe('Verify DELETE', function(){
            
            it('Delete a post', function(){

                cy.request({
                    method: 'DELETE',
                    url: TEST_URL + '/1',
                }).then(function(response){
                    expect(response.status).to.eq(200)
                    expect(response.body).to.be.empty
                });

            });

        });

    });

});